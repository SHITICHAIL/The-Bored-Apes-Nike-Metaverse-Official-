abstract class AnchorAccount {
  List<int> get discriminator;
}
