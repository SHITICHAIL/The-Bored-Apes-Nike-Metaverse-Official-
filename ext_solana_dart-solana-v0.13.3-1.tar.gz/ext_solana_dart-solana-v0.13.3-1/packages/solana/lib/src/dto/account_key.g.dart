// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'account_key.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

AccountKey _$AccountKeyFromJson(Map<String, dynamic> json) => AccountKey(
      pubkey: json['pubkey'] as String,
    );
