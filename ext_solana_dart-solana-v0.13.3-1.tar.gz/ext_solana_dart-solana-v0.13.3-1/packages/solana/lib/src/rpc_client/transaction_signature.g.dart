// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'transaction_signature.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

SignatureResponse _$SignatureResponseFromJson(Map<String, dynamic> json) =>
    SignatureResponse(
      json['result'] as String,
    );
