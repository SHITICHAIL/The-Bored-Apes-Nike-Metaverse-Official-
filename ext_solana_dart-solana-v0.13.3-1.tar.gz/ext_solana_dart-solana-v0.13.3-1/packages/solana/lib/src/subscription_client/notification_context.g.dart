// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'notification_context.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

NotificationContext _$NotificationContextFromJson(Map<String, dynamic> json) =>
    NotificationContext(
      slot: json['slot'] as int,
    );
