// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'optional_error.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

OptionalError _$OptionalErrorFromJson(Map<String, dynamic> json) =>
    OptionalError(
      err: json['err'],
    );
