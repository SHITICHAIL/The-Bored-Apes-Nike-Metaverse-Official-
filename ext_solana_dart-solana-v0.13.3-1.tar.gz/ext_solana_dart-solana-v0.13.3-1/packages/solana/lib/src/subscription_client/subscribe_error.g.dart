// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'subscribe_error.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

SubscribeError _$SubscribeErrorFromJson(Map<String, dynamic> json) =>
    SubscribeError(
      code: json['code'] as int,
      message: json['message'] as String,
    );
